from django.apps import AppConfig


class BillbookConfig(AppConfig):
    name = 'billbook'
