from django.apps import AppConfig


class WorkshopConfig(AppConfig):
    name = 'workshop'
