from django.apps import AppConfig


class ServicingConfig(AppConfig):
    name = 'servicing'
