package com.example.fyp_user.ui.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.fyp_user.R;
import com.example.fyp_user.network.gson_model.BillBook;
import com.example.fyp_user.network.gson_model.Response_BillBook;
import com.example.fyp_user.network.gson_model.Response_Servicing;

import java.util.ArrayList;
import java.util.List;

public class BillbookAdapter extends RecyclerView.Adapter<BillbookAdapter.ViewHolder> {


    private List<Response_BillBook> billBookList;

    public void setBillBookList(List<Response_BillBook> billBooks) {
        this.billBookList = billBooks;
        this.notifyDataSetChanged();
    }

    public BillbookAdapter(){
        billBookList=new ArrayList<>();
    }
    public BillbookAdapter(List<Response_BillBook> billBookList) {
        this.billBookList = billBookList;
    }

    @NonNull
    @Override
    public BillbookAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.listview,parent,false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BillbookAdapter.ViewHolder holder, int position) {
        Response_BillBook billBook=billBookList.get(position);
        holder.bindData("Billbook NO:"+billBook.getBill_book_no()+"\n"+"Pick Up:"+billBook.getPick_up_date());
    }

    @Override
    public int getItemCount() {
        return billBookList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        private TextView tvLable;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvLable=itemView.findViewById(R.id.label);
        }

        public void bindData(String data){
            tvLable.setText(data);
        }
    }
}


