package com.example.fyp_user.network.api;

import com.example.fyp_user.network.gson_model.User;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface UserApi {

    @POST("user/post/")
    Call<User> postUser(@Body User user);

    @GET("user/get/{uid}/")
    Call<User> getUser(@Path(value ="uid",encoded = true) String uid);

    @POST("user/update/{id}/")
    Call<User> updateUser(@Path(value ="id",encoded = true) String id, @Body  User user);
}
