package com.example.fyp_user.network.api;

import com.example.fyp_user.network.gson_model.User;
import com.example.fyp_user.network.gson_model.Vehicle;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface VehicleApi {

    @POST("vehicle/post/")
    Call<Vehicle> postVehicle(@Body Vehicle vehicle);

    @GET("vehicle/get/{id}/")
    Call<Vehicle> getVehicle(@Path(value ="id",encoded = true) String id);

    @GET("vehicle/users/{id}/")
    Call<Vehicle> getUserVehicle(@Path(value ="id",encoded = true) String id);

    @GET("vehicle/")
    Call<List<Vehicle>> getAllVehicle();

}
