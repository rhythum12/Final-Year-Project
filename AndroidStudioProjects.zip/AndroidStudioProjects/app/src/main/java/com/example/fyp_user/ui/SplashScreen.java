package com.example.fyp_user.ui;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import com.example.fyp_user.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class SplashScreen extends AppCompatActivity {

    private  int SPLASH_SCREEN_TIMEOUT=2000;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        mAuth=FirebaseAuth.getInstance();

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                FirebaseUser user=mAuth.getCurrentUser();
                Intent next_activity_intent=new Intent(getApplicationContext(),LoginActivity.class);
                if(user!=null){
                    next_activity_intent=new Intent(getApplicationContext(),DashboardActivity.class);
                }
                startActivity(next_activity_intent);
            }
        },SPLASH_SCREEN_TIMEOUT);
    }
}