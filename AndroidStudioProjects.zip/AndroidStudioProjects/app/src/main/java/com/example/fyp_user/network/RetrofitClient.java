package com.example.fyp_user.network;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitClient {
    static String baseUrl="http://192.168.0.7:8000/";

    public  static  Object LOCK=null;
    public static Retrofit INSTANCE;
    public static Retrofit getInstance(){
        if(LOCK==null){
            INSTANCE=new Retrofit.Builder()
                    .baseUrl(baseUrl)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return  INSTANCE;
    }

}
