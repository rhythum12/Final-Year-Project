package com.example.fyp_user.network.gson_model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class User {

    @SerializedName("id")
    private int id;

    @SerializedName("uid")
    private String uid;

    @SerializedName("fullname")
    private String fullname;


    @SerializedName("email")
    private String email;

    private String password;



    public  User(){}
    public User(String uid, String fullname, String email, String password) {
        this.uid = uid;
        this.fullname = fullname;
        this.email = email;
        this.password = password;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
