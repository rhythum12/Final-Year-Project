package com.example.fyp_user.network.api;

import com.example.fyp_user.network.gson_model.BillBook;
import com.example.fyp_user.network.gson_model.Response_Servicing;
import com.example.fyp_user.network.gson_model.Servicing;
import com.example.fyp_user.network.gson_model.User;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface ServicingApi {

    @GET("servicing/get_user_servicing/{user_id}/{category}/")
    Call<List<Response_Servicing>> getAllServicing(@Path(value ="user_id",encoded = true) String user_id, @Path(value ="category",encoded = true) String category);

    @POST("servicing/post/")
    Call<Servicing> postServicing(@Body Servicing servicing);
}
