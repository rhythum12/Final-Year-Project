package com.example.fyp_user.network.gson_model;

import com.google.gson.annotations.SerializedName;

public class Vehicle {

    @SerializedName("id")
    private String id;

    @SerializedName("name")
    private String name;

    @SerializedName("vehicle_type")
    private String vehicle_type;

    @SerializedName("color")
    private String color;

    @SerializedName("license_plate_no")
    private String license_plate_no;

    @SerializedName("user")
    private User user;

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Vehicle(String name, String vehicle_type, String color, String license_plate_no) {
        this.name = name;
        this.vehicle_type = vehicle_type;
        this.color = color;
        this.license_plate_no = license_plate_no;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getVehicle_type() {
        return vehicle_type;
    }

    public void setVehicle_type(String vehicle_type) {
        this.vehicle_type = vehicle_type;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getLicense_plate_no() {
        return license_plate_no;
    }

    public void setLicense_plate_no(String license_plate_no) {
        this.license_plate_no = license_plate_no;
    }
}


