package com.example.fyp_user.ui;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.view.MenuItem;

import com.example.fyp_user.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.DataCollectionDefaultChange;
import com.google.firebase.auth.FirebaseAuth;

public class DashboardActivity extends AppCompatActivity {

    private BottomNavigationView bottomNavigationView;
    private Fragment current_fragment;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        current_fragment=new DashboardFragment();

        bottomNavigationView=findViewById(R.id.bottom_nav_bar);

        getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.fragment,current_fragment)
                .commit();

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.bottom_nav_account:
                        current_fragment=new AccountFragment();
                        break;
                    case R.id.bottom_nav_home:
                        current_fragment=new DashboardFragment();
                        break;
                }
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.fragment,current_fragment)
                        .commit();

                return true;
            }
        });
    }
}