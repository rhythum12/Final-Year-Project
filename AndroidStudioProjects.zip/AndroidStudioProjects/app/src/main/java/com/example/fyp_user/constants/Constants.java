package com.example.fyp_user.constants;

import com.example.fyp_user.network.gson_model.User;

public class Constants {
    public static User user;

}

