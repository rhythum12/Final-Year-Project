package com.example.fyp_user.ui;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import com.example.fyp_user.R;
import com.example.fyp_user.constants.Constants;
import com.example.fyp_user.network.RetrofitClient;
import com.example.fyp_user.network.api.BillBookApi;
import com.example.fyp_user.network.api.ServicingApi;
import com.example.fyp_user.network.gson_model.BillBook;
import com.example.fyp_user.network.gson_model.Response_BillBook;
import com.example.fyp_user.network.gson_model.Response_Servicing;
import com.example.fyp_user.network.gson_model.Servicing;
import com.example.fyp_user.ui.adapter.BillbookAdapter;
import com.example.fyp_user.ui.adapter.ServicesAdapter;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class BookingActivity extends AppCompatActivity {

    private  Retrofit retrofit;
    private String STATUS_CATEGORY="ON-Hold";

    private List<Response_BillBook> billBookList=new ArrayList<>();
    private List<Response_Servicing> servicingList=new ArrayList<>();

    private Button btnOnHold,btnDone,btnCancled;
    private RecyclerView rvBillBook,rvServicing;

    private BillbookAdapter billBookAdapter;
    private ServicesAdapter servicesAdapter;

    RecyclerView.LayoutManager billBookLM,servicesLM;


    private Handler loadBillBookDataHandler=new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {
            billBookList= (List<Response_BillBook>) msg.obj;
            billBookAdapter.setBillBookList(billBookList);
            return false;
        }
    });


    private Handler loadServicingHandler=new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {
            servicingList= (List<Response_Servicing>) msg.obj;
            servicesAdapter.setServicingList(servicingList);
            return false;
        }
    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking);




        retrofit= RetrofitClient.getInstance();

        rvBillBook=findViewById(R.id.rv_billbook);
        rvServicing=findViewById(R.id.rv_servicing);

        btnOnHold=findViewById(R.id.btn_on_hold);
        btnCancled=findViewById(R.id.btn_cancled);
        btnDone=findViewById(R.id.btn_done);

        btnOnHold.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadServicing("ON-Hold");
                loadBillBook("ON-Hold");
            }
        });
        btnCancled.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadBillBook("CANCLED");
                loadServicing("CANCLED");
            }
        });
        btnDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadBillBook("DONE");
                loadServicing("DONE");
            }
        });

        billBookLM=new LinearLayoutManager(this);
        servicesLM=new LinearLayoutManager(this);

        billBookAdapter=new BillbookAdapter();
        servicesAdapter=new ServicesAdapter();


        rvBillBook.setAdapter(billBookAdapter);
        rvServicing.setAdapter(servicesAdapter);

        rvServicing.setLayoutManager(servicesLM);
        rvBillBook.setLayoutManager(billBookLM);


        loadBillBook(STATUS_CATEGORY);
        loadServicing(STATUS_CATEGORY);
    }


    public void loadBillBook(String STATUS_CATEGORY){
        BillBookApi billBookApi=retrofit.create(BillBookApi.class);
        Call<List<Response_BillBook>> billbookCall=billBookApi.getAllBillBook(String.valueOf(Constants.user.getId()),STATUS_CATEGORY);

        billbookCall.enqueue(new Callback<List<Response_BillBook>>() {
            @Override
            public void onResponse(Call<List<Response_BillBook>> call, Response<List<Response_BillBook>> response) {
                if(response.isSuccessful()){
                    List<Response_BillBook> billBookList=response.body();

                    Message msg=new Message();
                    msg.obj=billBookList;

                    loadBillBookDataHandler.sendMessage(msg);

                }
            }

            @Override
            public void onFailure(Call<List<Response_BillBook>> call, Throwable t) {

            }
        });
    }

    public void loadServicing(String STATUS_CATEGORY){
        ServicingApi servicingApi=retrofit.create(ServicingApi.class);
        Call<List<Response_Servicing>> servicingCall=servicingApi.getAllServicing(String.valueOf(Constants.user.getId()),STATUS_CATEGORY);

        servicingCall.enqueue(new Callback<List<Response_Servicing>>() {
            @Override
            public void onResponse(Call<List<Response_Servicing>> call, Response<List<Response_Servicing>> response) {
                if(response.isSuccessful()){
                    List<Response_Servicing> servicingList=response.body();
                    Message msg=new Message();
                    msg.obj=servicingList;

                    loadServicingHandler.sendMessage(msg);
                }
            }

            @Override
            public void onFailure(Call<List<Response_Servicing>> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }

}