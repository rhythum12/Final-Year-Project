package com.example.fyp_user.network.gson_model;

import com.google.gson.annotations.SerializedName;

public class BillBook {

    @SerializedName("id")
    private int id;

    @SerializedName("user")
    private User user;

    @SerializedName("bill_book_no")
    private String bill_book_no;

    @SerializedName("latitude")
    private Float latitude;

    @SerializedName("longitude")
    private Float longitude;

    @SerializedName("pick_up_date")
    private String pick_up_date;

    @SerializedName("status")
    private String status;

    public BillBook(User user, String bill_book_no, Float latitude, Float longitude, String pick_up_date, String status) {
        this.user = user;
        this.bill_book_no = bill_book_no;
        this.latitude = latitude;
        this.longitude = longitude;
        this.pick_up_date = pick_up_date;
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getBill_book_no() {
        return bill_book_no;
    }

    public void setBill_book_no(String bill_book_no) {
        this.bill_book_no = bill_book_no;
    }

    public Float getLatitude() {
        return latitude;
    }

    public void setLatitude(Float latitude) {
        this.latitude = latitude;
    }

    public Float getLongitude() {
        return longitude;
    }

    public void setLongitude(Float longitude) {
        this.longitude = longitude;
    }

    public String getPick_up_date() {
        return pick_up_date;
    }

    public void setPick_up_date(String pick_up_date) {
        this.pick_up_date = pick_up_date;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
