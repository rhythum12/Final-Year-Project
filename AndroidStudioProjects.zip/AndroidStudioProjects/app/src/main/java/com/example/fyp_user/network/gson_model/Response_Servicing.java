package com.example.fyp_user.network.gson_model;

import com.google.gson.annotations.SerializedName;

public class Response_Servicing {

    @SerializedName("user")
    private int user;



    @SerializedName("id")
    private String id;

    @SerializedName("vehicle_name")
    private String vehicle_name;

    @SerializedName("vehicle_type")
    private String vehicle_type;

    @SerializedName("color")
    private String color;

    @SerializedName("license_plate_no")
    private String license_plate_no;


    @SerializedName("latitude")
    private Float latitude;

    @SerializedName("longitude")
    private Float longitude;

    @SerializedName("pick_up_date")
    private String pick_up_date;

    @SerializedName("status")
    private String status;

    public Response_Servicing(int user, String vehicle_name, String vehicle_type, String color, String license_plate_no, Float latitude, Float longitude, String pick_up_date, String status) {
        this.user = user;
        this.vehicle_name = vehicle_name;
        this.vehicle_type = vehicle_type;
        this.color = color;
        this.license_plate_no = license_plate_no;
        this.latitude = latitude;
        this.longitude = longitude;
        this.pick_up_date = pick_up_date;
        this.status = status;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getUser() {
        return user;
    }

    public void setUser(int user) {
        this.user = user;
    }

    public String getVehicle_name() {
        return vehicle_name;
    }

    public void setVehicle_name(String vehicle_name) {
        this.vehicle_name = vehicle_name;
    }

    public String getVehicle_type() {
        return vehicle_type;
    }

    public void setVehicle_type(String vehicle_type) {
        this.vehicle_type = vehicle_type;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getLicense_plate_no() {
        return license_plate_no;
    }

    public void setLicense_plate_no(String license_plate_no) {
        this.license_plate_no = license_plate_no;
    }

    public Float getLatitude() {
        return latitude;
    }

    public void setLatitude(Float latitude) {
        this.latitude = latitude;
    }

    public Float getLongitude() {
        return longitude;
    }

    public void setLongitude(Float longitude) {
        this.longitude = longitude;
    }

    public String getPick_up_date() {
        return pick_up_date;
    }

    public void setPick_up_date(String pick_up_date) {
        this.pick_up_date = pick_up_date;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
