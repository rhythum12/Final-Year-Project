package com.example.fyp_user.network.api;

import com.example.fyp_user.network.gson_model.BillBook;
import com.example.fyp_user.network.gson_model.Response_BillBook;
import com.example.fyp_user.network.gson_model.Vehicle;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface BillBookApi {

    @GET("billbook/get_user_billbook/{user_id}/{category}/")
    Call<List<Response_BillBook>> getAllBillBook(@Path(value ="user_id",encoded = true) String user_id, @Path(value ="category",encoded = true) String category);

    @POST("billbook/post/")
    Call<BillBook> postBillBook(@Body BillBook billBook);
}
