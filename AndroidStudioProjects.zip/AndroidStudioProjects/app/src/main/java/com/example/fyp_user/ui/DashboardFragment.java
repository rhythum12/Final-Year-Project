package com.example.fyp_user.ui;

import android.content.Intent;
import android.location.Location;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.fyp_user.R;
import com.example.fyp_user.constants.Constants;
import com.example.fyp_user.network.RetrofitClient;
import com.example.fyp_user.network.api.UserApi;
import com.example.fyp_user.network.gson_model.User;
import com.google.firebase.auth.FirebaseAuth;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class DashboardFragment extends Fragment {

    private TextView tvWelcomeUser;
    private FirebaseAuth mAuth;
    private CardView cvBillBook,cvServicing,cvBooking,cvVehicles,cvMaps;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_dashboard, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mAuth=FirebaseAuth.getInstance();

        cvBillBook=view.findViewById(R.id.card_billbook);
        cvServicing=view.findViewById(R.id.card_servicing);
        cvBooking=view.findViewById(R.id.card_booking);
        cvVehicles=view.findViewById(R.id.card_vehicles);
        cvMaps=view.findViewById(R.id.card_map);


        tvWelcomeUser=view.findViewById(R.id.tv_welcome_user);

        setGreetings();
        setOnClicks();
    }

    public void setGreetings(){
        if(mAuth.getCurrentUser()!=null){
            String name=mAuth.getCurrentUser().getEmail();
            tvWelcomeUser.setText("Welcome "+name.split("@")[0].toUpperCase());
        }
    }

    public void setOnClicks(){
        cvVehicles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getContext(),VehicleActivity.class));
            }
        });
        cvBooking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getContext(),BookingActivity.class));
            }
        });
        cvServicing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getContext(),ServicingActivity.class));
            }
        });
        cvBillBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getContext(),BillBookActivity.class));
            }
        });

        cvMaps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getContext(),MapsActivity.class));

            }
        });
        requestAccountData();
    }

    public void requestAccountData(){
        UserApi userApi= RetrofitClient.getInstance().create(UserApi.class);
        Call<User> userCall=userApi.getUser(mAuth.getCurrentUser().getUid());

        userCall.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.isSuccessful()){
                    User user=response.body();
                    Message msg=new Message();
                    msg.obj=user;
                    Constants.user=user;
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {
            }
        });
    }

}