package com.example.fyp_user.ui;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.Toast;

import com.example.fyp_user.R;
import com.example.fyp_user.network.RetrofitClient;
import com.example.fyp_user.network.api.WorkshopApi;
import com.example.fyp_user.network.gson_model.Workshop;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;

    private Location current_location;

    private FusedLocationProviderClient fusedLocationProviderClient;

    private List<Workshop> workshopList;

    private Retrofit retrofit;

    private int REQUEST_LOCATION_CODE = 10001;

    @Override
    protected void onStart() {
        super.onStart();

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            getLastLocation();
        } else {
            askLocation();
        }
    }



    public void getLastLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        Task<Location> locationTask = fusedLocationProviderClient.getLastLocation();
        locationTask.addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if(location==null)
                    return;

                current_location=location;
                moveMap();
            }
        });

        locationTask.addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getApplicationContext(), "Location Permission Not garnted", Toast.LENGTH_SHORT).show();

            }
        });
    }

    public void askLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_FINE_LOCATION)) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION_CODE);
            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION_CODE);

            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_LOCATION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getLastLocation();
            } else {
                Toast.makeText(this, "Location Permission Not garnted", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);

        retrofit= RetrofitClient.getInstance();

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }


    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        loadWorkshop();

        if(current_location==null)
            return;
        // Add a marker in Sydney and move the camera
        LatLng location = new LatLng(current_location.getLatitude(), current_location.getLongitude());
        mMap.addMarker(new MarkerOptions().position(location).title("You location"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(location));
    }

    public void moveMap(){
        if(current_location==null)
            return;
        // Add a marker in Sydney and move the camera
        LatLng location = new LatLng(current_location.getLatitude(), current_location.getLongitude());

        mMap.addMarker(new MarkerOptions().position(location).title("You location"));


        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(location,15));
    }


    public Handler handelOnMapLoad=new Handler(){

        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            workshopList= (List<Workshop>) msg.obj;
            loadWorkshopOnMap();
        }
    };
    public void loadWorkshop(){
        WorkshopApi workshopApi= retrofit.create(WorkshopApi.class);

        Call<List<Workshop>> workshopCall=workshopApi.getAllWorkshop();

        workshopCall.enqueue(new Callback<List<Workshop>>() {
            @Override
            public void onResponse(Call<List<Workshop>> call, Response<List<Workshop>> response) {
                if(response.isSuccessful()){
                    Message msg=new Message();
                    msg.obj=response.body();
                    handelOnMapLoad.sendMessage(msg);
                }
            }

            @Override
            public void onFailure(Call<List<Workshop>> call, Throwable t) {

            }
        });
    }


    public void loadWorkshopOnMap(){
        for(Workshop workshop:workshopList){

            LatLng location = new LatLng(workshop.latitude, workshop.longitude);
            mMap.addMarker(new MarkerOptions().position(location).title(workshop.workshop_name));


        }
    }

}