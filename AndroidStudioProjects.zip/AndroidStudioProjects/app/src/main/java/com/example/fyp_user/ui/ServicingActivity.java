package com.example.fyp_user.ui;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.fyp_user.R;
import com.example.fyp_user.constants.Constants;
import com.example.fyp_user.network.RetrofitClient;
import com.example.fyp_user.network.api.ServicingApi;
import com.example.fyp_user.network.gson_model.Servicing;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class ServicingActivity extends AppCompatActivity {

    private EditText etVehicleName, etVehicleType, etColor, etLicensePlateNo, etPickUpDate;
    private TextView tvLatLong;

    private Button btnAddServicing;

    private Retrofit retrofit;

    private Location current_location;

    private FusedLocationProviderClient fusedLocationProviderClient;


    private int REQUEST_LOCATION_CODE = 10001;

    @Override
    protected void onStart() {
        super.onStart();

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            getLastLocation();
        } else {
            askLocation();
        }
    }

    public void getLastLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        Task<Location> locationTask = fusedLocationProviderClient.getLastLocation();
        locationTask.addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if(location==null)
                        return;

                current_location=location;
                tvLatLong.setText(String.valueOf(location.getLongitude())+String.valueOf(location.getLongitude()));
            }
        });

        locationTask.addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getApplicationContext(), "Location Permission Not garnted", Toast.LENGTH_SHORT).show();

            }
        });
    }

    public void askLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_FINE_LOCATION)) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION_CODE);
            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION_CODE);

            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_LOCATION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getLastLocation();
            } else {
                Toast.makeText(this, "Location Permission Not garnted", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_servicing);

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        retrofit = RetrofitClient.getInstance();


        etColor = findViewById(R.id.et_vehicle_color);
        etVehicleName = findViewById(R.id.et_bill_book_no);
        etVehicleType = findViewById(R.id.et_vehicle_type);
        etLicensePlateNo = findViewById(R.id.et_vehicle_license);
        etPickUpDate = findViewById(R.id.etPickUpDate);
        tvLatLong = findViewById(R.id.tv_lat_long);

        btnAddServicing = findViewById(R.id.btn_add_bill_book);

        btnAddServicing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                postServicingData();
            }
        });

    }

    public void postServicingData() {
        String color = etColor.getText().toString();
        String name = etVehicleName.getText().toString();
        String type = etVehicleType.getText().toString();
        String plate_no = etLicensePlateNo.getText().toString();
        color.equals("");
        String pick_up = etPickUpDate.getText().toString();

        if (color.equals("") || pick_up.equals("") || name.equals("") || type.equals("") || plate_no.equals("") || color.equals("")) {
            Toast.makeText(getApplicationContext(), "Fill All Fidels", Toast.LENGTH_SHORT).show();
            return;
        }

        postServicing(new Servicing(
                Constants.user,
                name,
                type,
                color,
                plate_no,
                Float.parseFloat(String.valueOf(current_location.getLatitude())),
                Float.parseFloat(String.valueOf(current_location.getLongitude())),
                pick_up,
                "ON-Hold"
        ));


    }

    public void postServicing(Servicing servicing) {
        ServicingApi servicingApi = retrofit.create(ServicingApi.class);
        Call<Servicing> servicingCall = servicingApi.postServicing(servicing);
        servicingCall.enqueue(new Callback<Servicing>() {
            @Override
            public void onResponse(Call<Servicing> call, Response<Servicing> response) {
                if (response.isSuccessful()) {

                }
            }

            @Override
            public void onFailure(Call<Servicing> call, Throwable t) {

            }
        });
    }
}