package com.example.fyp_user.ui.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.fyp_user.R;
import com.example.fyp_user.network.gson_model.Response_Servicing;
import com.example.fyp_user.network.gson_model.Servicing;

import java.util.ArrayList;
import java.util.List;

import retrofit2.http.PUT;

public class ServicesAdapter extends RecyclerView.Adapter<ServicesAdapter.ViewHolder> {


    private List<Response_Servicing> servicingList;

    public void setServicingList(List<Response_Servicing> servicingList) {
        this.servicingList = servicingList;
        this.notifyDataSetChanged();
    }

    public ServicesAdapter(){
        servicingList=new ArrayList<>();
    }
    public ServicesAdapter(List<Response_Servicing> servicingList) {
        this.servicingList = servicingList;
    }

    @NonNull
    @Override
    public ServicesAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.listview,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ServicesAdapter.ViewHolder holder, int position) {
        Response_Servicing servicing=servicingList.get(position);
        holder.bindData("Vehicle Name:"+servicing.getVehicle_name()+"\nCOLOR"+servicing.getColor()+"\nLicense No"+servicing.getLicense_plate_no());
    }

    @Override
    public int getItemCount() {
        return servicingList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        private TextView tvLable;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvLable=itemView.findViewById(R.id.label);
        }

        public void bindData(String data){
            tvLable.setText(data);
        }
    }
}


