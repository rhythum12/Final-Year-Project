package com.example.fyp_user.ui;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.fyp_user.R;
import com.example.fyp_user.constants.Constants;
import com.example.fyp_user.network.RetrofitClient;
import com.example.fyp_user.network.api.UserApi;
import com.example.fyp_user.network.gson_model.User;
import com.google.firebase.auth.FirebaseAuth;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;


public class AccountFragment extends Fragment {


    private Button btnLogout;

    private FirebaseAuth mAuth;

    private Retrofit retrofitClient;

    private TextView tvUsername,tvEmail;

    private Handler loadAccountDataHandler=new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {
            loadAccountData((User) msg.obj);
            return false;
        }
    });

    private Handler errorHandler=new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {
            Toast.makeText(getContext(),"Network Error",Toast.LENGTH_SHORT);
            return false;
        }
    });
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_account, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mAuth=FirebaseAuth.getInstance();
        retrofitClient=RetrofitClient.getInstance();


        btnLogout=view.findViewById(R.id.btn_logout);
        tvEmail=view.findViewById(R.id.tv_email);
        tvUsername=view.findViewById(R.id.tv_username);
        requestAccountData();

        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mAuth.signOut();
                startActivity(new Intent(getActivity().getApplicationContext(),LoginActivity.class));
            }
        });
    }

    public void requestAccountData(){
        UserApi userApi=retrofitClient.create(UserApi.class);
        Call<User> userCall=userApi.getUser(mAuth.getCurrentUser().getUid());

        userCall.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.isSuccessful()){
                    User user=response.body();
                    Message msg=new Message();
                    msg.obj=user;
                    Constants.user=user;
                    loadAccountDataHandler.sendMessage(msg);
                }else {
                    errorHandler.sendMessage(new Message());
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {
                errorHandler.sendMessage(new Message());
            }
        });
    }

    public void loadAccountData(User user){
        tvUsername.setText(user.getFullname());
        tvEmail.setText(user.getEmail());
    }
}