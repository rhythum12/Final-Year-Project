package com.example.fyp_user.network.gson_model;

import com.google.gson.annotations.SerializedName;

public class Workshop {

    @SerializedName("id")
    public int id;

    @SerializedName("workshop_name")
    public String workshop_name;

    @SerializedName("latitude")
    public double latitude;

    @SerializedName("longitude")
    public double longitude;

    public Workshop(String workshop_name, double latitude, double longitude) {
        this.workshop_name = workshop_name;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getWorkshop_name() {
        return workshop_name;
    }

    public void setWorkshop_name(String workshop_name) {
        this.workshop_name = workshop_name;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }
}
