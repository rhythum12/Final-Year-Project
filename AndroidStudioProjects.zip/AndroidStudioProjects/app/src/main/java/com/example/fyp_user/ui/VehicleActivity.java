package com.example.fyp_user.ui;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.fyp_user.R;
import com.example.fyp_user.constants.Constants;
import com.example.fyp_user.network.RetrofitClient;
import com.example.fyp_user.network.api.VehicleApi;
import com.example.fyp_user.network.gson_model.Vehicle;
import com.google.firebase.auth.FirebaseAuth;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class VehicleActivity extends AppCompatActivity {

    private EditText etVehicleName,etVehicleColor,etVehicleLicenseNo,etVehicleType;
    private TextView tvVehicleName,tvVehicleColor,tvLicenseNo,tvVehicleType;

    private Button btnAddVehicle;
    private Retrofit retrofit;
    private FirebaseAuth mAuth;

    private Handler loadVehicleDataHandler=new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {
            loadVehicle((Vehicle) msg.obj);
            return false;
        }
    });

    private Handler errorHandler=new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {
            Toast.makeText(getApplicationContext(),"Network Error",Toast.LENGTH_SHORT);
            return false;
        }
    });


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vehicle);

        retrofit= RetrofitClient.getInstance();
        mAuth=FirebaseAuth.getInstance();

        etVehicleColor=findViewById(R.id.et_vehicle_color);
        etVehicleLicenseNo=findViewById(R.id.et_vehicle_license);
        etVehicleName=findViewById(R.id.et_bill_book_no);
        etVehicleType=findViewById(R.id.et_vehicle_type);

        tvLicenseNo=findViewById(R.id.tv_license_no);
        tvVehicleName=findViewById(R.id.tv_vehicle_name);
        tvVehicleColor=findViewById(R.id.tv_vehicel_color);
        tvVehicleType=findViewById(R.id.tv_vehicle_type);


        btnAddVehicle=findViewById(R.id.btn_add_bill_book);

        btnAddVehicle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addVehicle();
            }
        });

        getVehicle();

    }


    public void loadVehicle(Vehicle vehicle){
        tvVehicleType.setText(vehicle.getVehicle_type());
        tvVehicleName.setText(vehicle.getName());
        tvVehicleColor.setText(vehicle.getColor());
        tvLicenseNo.setText(vehicle.getLicense_plate_no());
    }

    public void addVehicle(){
        String name=etVehicleName.getText().toString();
        String color=etVehicleColor.getText().toString();
        String license_no=etVehicleLicenseNo.getText().toString();
        String vehicle_type=etVehicleType.getText().toString();

        if(name.equals("") || color.equals("") || license_no.equals("") || vehicle_type.equals("") ){
            Toast.makeText(getApplicationContext(), " Fill All Data",Toast.LENGTH_SHORT).show();
            return;
        }

        Vehicle vehicle= new Vehicle(name,vehicle_type,color,license_no);
        vehicle.setUser(Constants.user);
        postVehicle(vehicle);

    }

    public void getVehicle(){
        VehicleApi vehicleApi=retrofit.create(VehicleApi.class);
        Call<Vehicle> vehicleCall=vehicleApi.getUserVehicle(String.valueOf(Constants.user.getId()));
        vehicleCall.enqueue(new Callback<Vehicle>() {
            @Override
            public void onResponse(Call<Vehicle> call, Response<Vehicle> response) {
                if(response.isSuccessful()){
                    Message msg=new Message();
                    msg.obj=response.body();

                    loadVehicleDataHandler.sendMessage(msg);
                }
            }

            @Override
            public void onFailure(Call<Vehicle> call, Throwable t) {

            }
        });

    }
    public void postVehicle(Vehicle vehicle){
        VehicleApi vehicleApi=retrofit.create(VehicleApi.class);
        Call<Vehicle> vehicleCall=vehicleApi.postVehicle(vehicle);

        vehicleCall.enqueue(new Callback<Vehicle>() {
            @Override
            public void onResponse(Call<Vehicle> call, Response<Vehicle> response) {
                if(response.isSuccessful()){
                    Vehicle v=response.body();
                    Message message=new Message();
                    message.obj=v;

                    loadVehicleDataHandler.sendMessage(message);
                }else {
                    errorHandler.sendMessage(new Message());
                }
            }

            @Override
            public void onFailure(Call<Vehicle> call, Throwable t) {
                errorHandler.sendMessage(new Message());
            }
        });
    }


}