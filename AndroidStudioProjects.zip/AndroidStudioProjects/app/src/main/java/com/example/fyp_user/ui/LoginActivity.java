package com.example.fyp_user.ui;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.fyp_user.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class LoginActivity extends AppCompatActivity {

    private EditText etEmail,etPassword;
    private  TextView tv_sign_up;
    private Button btn_login;

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        mAuth=FirebaseAuth.getInstance();

        btn_login=findViewById(R.id.btn_login);

        etEmail=findViewById(R.id.et_login_email);
        etPassword=findViewById(R.id.et_login_password);
        tv_sign_up=findViewById(R.id.tv_login_sign_up);

        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login();
            }
        });

        tv_sign_up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToSignUp();
            }
        });
    }

    public void login(){
        String email=etEmail.getText().toString();
        String password=etPassword.getText().toString();

        if(email.equals("")){
            Toast.makeText(getApplicationContext(),"Enter Email",Toast.LENGTH_SHORT);
            return;
        }
        if(password.equals("")){
            Toast.makeText(getApplicationContext(),"Enter Password",Toast.LENGTH_SHORT);
            return;
        }

        loginWithEmailAndPassword(email,password);
    }

    public void navigateToSignUp(){
        Intent signUp=new Intent(getApplicationContext(),SignUpActivity.class);
        startActivity(signUp);
    }

    public void loginWithEmailAndPassword(String email, String password){
        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            FirebaseUser user = mAuth.getCurrentUser();
                            navigateToDashBoard();
                        } else {
                            Toast.makeText(getApplicationContext(), "Authentication failed.",
                                    Toast.LENGTH_SHORT).show();
                        }
                    }});
    }

    public void navigateToDashBoard(){
        Intent dashboard=new Intent(getApplicationContext(),DashboardActivity.class);
        startActivity(dashboard);
    }
}