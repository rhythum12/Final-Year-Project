package com.example.fyp_user.ui;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.fyp_user.R;
import com.example.fyp_user.network.RetrofitClient;
import com.example.fyp_user.network.api.UserApi;
import com.example.fyp_user.network.gson_model.User;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class SignUpActivity extends AppCompatActivity {

    private EditText etEmail,etPassword,etUsername,etRePassword;
    private TextView tv_login;
    private Button btn_sign_up;

    private FirebaseAuth mAuth;

    private Retrofit retrofit;

    private Handler navigateToLoginHandler=new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            navigateToLogin();
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mAuth=FirebaseAuth.getInstance();
        retrofit= RetrofitClient.getInstance();

        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        setContentView(R.layout.activity_sign_up);

        etEmail=findViewById(R.id.et_sign_up_email);
        etPassword=findViewById(R.id.et_sign_up_password);
        etUsername=findViewById(R.id.et_sign_up_name);
        etRePassword=findViewById(R.id.et_re_enter_password);

        tv_login=findViewById(R.id.tv_sign_up_login);
        btn_sign_up=findViewById(R.id.btn_sign_up);

        tv_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToLogin();
            }
        });

        btn_sign_up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sign_up();
            }
        });
    }

    public void sign_up(){
        String email=etEmail.getText().toString();
        String username=etUsername.getText().toString();
        String re_password=etRePassword.getText().toString();
        String password=etPassword.getText().toString();

        if(username.equals("")){
            Toast.makeText(getApplicationContext(),"Enter Email",Toast.LENGTH_SHORT).show();
            return;
        }

        if(email.equals("")){
            Toast.makeText(getApplicationContext(),"Enter Email",Toast.LENGTH_SHORT).show();
            return;
        }

        if(password.equals("") || re_password.equals("")){
            Toast.makeText(getApplicationContext(),"Enter Password",Toast.LENGTH_SHORT).show();
            return;
        }
        if(!password.equals(re_password) ){
            Toast.makeText(getApplicationContext(),"Password Mis-Match",Toast.LENGTH_SHORT).show();

        }

        if(!(password.length()>8)){
            Toast.makeText(getApplicationContext(),"Password Length Must Be greater than 8",Toast.LENGTH_SHORT).show();
            return;
        }


        User user=new User();
        user.setEmail(email);
        user.setFullname(username);
        user.setPassword(password);

        signUpWithEmailAndPassword(user);

    }

    public void navigateToLogin(){
        Intent login=new Intent(getApplicationContext(),LoginActivity.class);
        startActivity(login);
    }

    public void signUpWithEmailAndPassword(User user){
        mAuth.createUserWithEmailAndPassword(user.getEmail(),user.getPassword())
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()){
                            user.setUid(FirebaseAuth.getInstance().getUid());
                            postUser(user);
                        }else{
                            Toast.makeText(getApplicationContext(), "Authentication failed.",Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    public void postUser(User user){
        UserApi userApi=retrofit.create(UserApi.class);

        Call<User> userCall=userApi.postUser(user);

        userCall.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.code()==200){
                    navigateToLoginHandler.sendMessage(new Message());
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {
                Toast.makeText(getApplicationContext(),t.getMessage(),Toast.LENGTH_SHORT).show();
            }
        });
    }

}