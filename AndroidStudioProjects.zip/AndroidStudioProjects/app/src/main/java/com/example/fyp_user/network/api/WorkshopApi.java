package com.example.fyp_user.network.api;

import com.example.fyp_user.network.gson_model.Workshop;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface WorkshopApi {

    @GET("workshop/")
    Call<List<Workshop>> getAllWorkshop();

}
